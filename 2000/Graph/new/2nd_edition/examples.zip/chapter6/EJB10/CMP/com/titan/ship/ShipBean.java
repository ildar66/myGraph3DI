package com.titan.ship;

import javax.ejb.EntityContext;

public class ShipBean implements javax.ejb.EntityBean {
    public int id;
    public String name;
    public int capacity;
    public double tonnage;

    public EntityContext context;
    
    
    public void ejbCreate(int id, String name, int capacity,
                          double tonnage){
        this.id = id;
        this.name = name;
        this.capacity = capacity;
        this.tonnage = tonnage;
    }
    public void ejbPostCreate(int id, String name, int capacity,
                              double tonnage){
        ShipPK pk = (ShipPK)context.getPrimaryKey();
        // Do something useful with the primary key.
    }
    public void ejbCreate(int id, String name){
        this.id = id;
        this.name = name;
        capacity = 0;
        tonnage = 0;
    }
    public void ejbPostCreate(int id, String name){
        Ship myself = (Ship)context.getEJBObject();
        // Do something useful with the EJBObject reference.
    }
    public void setEntityContext(EntityContext ctx){
        context = ctx;
    }
    public void unsetEntityContext(){ 
        context = null;
    }
    public void ejbActivate(){ }
    public void ejbPassivate(){ }
    public void ejbLoad(){ }
    public void ejbStore(){ }
    public void ejbRemove(){ }

    public String getName(){
        return name;
    }
    public void setName(String n){
        name = n;
    }
    public void setCapacity(int cap){
        capacity = cap;
    }
    public int getCapacity(){
        return capacity;
    }
    public double getTonnage(){
        return tonnage;
    }
    public void setTonnage(double tons){
        tonnage = tons;
    }
}
