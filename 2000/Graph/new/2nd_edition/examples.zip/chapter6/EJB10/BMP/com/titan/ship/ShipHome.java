package com.titan.ship;

import javax.ejb.EJBHome;
import javax.ejb.CreateException;
import javax.ejb.FinderException;
import java.rmi.RemoteException;
import java.util.Enumeration;

public interface ShipHome extends javax.ejb.EJBHome {

    public Ship create(int id, String name, int capacity, double tonnage)
        throws RemoteException,CreateException;
    public Ship create(int id, String name)
        throws RemoteException,CreateException;
    public Ship findByPrimaryKey(ShipPK primaryKey)
        throws FinderException, RemoteException;
    public Enumeration findByCapacity(int capacity)
        throws FinderException, RemoteException;
}
