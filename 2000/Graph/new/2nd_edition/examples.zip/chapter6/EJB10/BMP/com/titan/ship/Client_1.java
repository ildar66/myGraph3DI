package com.titan.ship;

import javax.naming.InitialContext;
import javax.naming.Context;
import javax.naming.NamingException;
import java.rmi.RemoteException;
import java.util.Properties;

public class Client_1 {
    public static void main(String [] args){
        try {
            Context ctx = getInitialContext();
            // EJB 1.1: Use PortableRemoteObject.narrow() method
            ShipHome home = (ShipHome)ctx.lookup("ShipHome");

            Ship ship = home.create(1,"Paradise",3000,100000);
            int t = ship.getCapacity();
            System.out.println("Capacity = " +t);

        } catch (Exception e){e.printStackTrace();}
    }
    public static Context getInitialContext() 
        throws javax.naming.NamingException{

        Properties p = new Properties();
        // ... Specify the JNDI properties specific to the vendor.
        return new javax.naming.InitialContext(p);
    }
}
