#!/bin/sh
# run cabin Client_1

java -classpath $CLASSPATH:$J2EE_HOME/lib/j2ee.jar:.:cabintestClient.jar com.titan.cabin.Client_1


