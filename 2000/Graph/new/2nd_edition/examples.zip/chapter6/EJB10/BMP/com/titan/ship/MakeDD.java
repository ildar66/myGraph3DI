package com.titan.ship;

import javax.ejb.deployment.EntityDescriptor;
import javax.ejb.deployment.ControlDescriptor;
import javax.naming.CompoundName;
import java.util.Properties;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.lang.reflect.Field;

public class MakeDD {

    public static void main(String args [] ){
        try {

        if(args.length <1){
            System.out.println("must specify target directory");
            return;
        }
        EntityDescriptor shipDD = new EntityDescriptor();
        shipDD.setEnterpriseBeanClassName("com.titan.ship.ShipBean");
        shipDD.setHomeInterfaceClassName("com.titan.ship.ShipHome");
        shipDD.setRemoteInterfaceClassName("com.titan.ship.Ship");
        shipDD.setPrimaryKeyClassName("com.titan.ship.ShipPK");

        /* COMMENTED OUT FOR BEAN-MANAGED SHIP BEAN
        *****************************************
        Class beanClass = ShipBean.class;
        Field [] persistentFields = new Field[4];
        persistentFields[0] = beanClass.getDeclaredField("id");
        persistentFields[1] = beanClass.getDeclaredField("name");
        persistentFields[2] = beanClass.getDeclaredField("capacity");
        persistentFields[3] = beanClass.getDeclaredField("tonnage");
        shipDD.setContainerManagedFields(persistentFields);

        ************************
        */

        Properties props = new Properties();
        props.put("jdbcURL","jdbc:<subprotocol>:<subname>");
        shipDD.setEnvironmentProperties(props);


        shipDD.setReentrant(false);

        CompoundName jndiName = 
            new CompoundName("ShipHome", new Properties());
        shipDD.setBeanHomeName(jndiName);

        ControlDescriptor cd = new ControlDescriptor();
        cd.setIsolationLevel(ControlDescriptor.TRANSACTION_READ_COMMITTED );
        cd.setMethod(null);
        cd.setRunAsMode(ControlDescriptor.CLIENT_IDENTITY);
        cd.setTransactionAttribute(ControlDescriptor.TX_REQUIRED);
        ControlDescriptor [] cdArray = {cd};
        shipDD.setControlDescriptors(cdArray);

        // Set the name to associate with the enterprise bean
        // in the JNDI name space.

        String fileSeparator = 
            System.getProperties().getProperty("file.separator");

        if (! args[0].endsWith(fileSeparator))
            args[0] += fileSeparator;

        FileOutputStream fis = new FileOutputStream(args[0]+"ShipDD.ser");
        ObjectOutputStream oos = new ObjectOutputStream(fis);
        oos.writeObject(shipDD);
        oos.flush();
        oos.close();
        fis.close();
        } catch (Throwable t){t.printStackTrace();}
    }
}
