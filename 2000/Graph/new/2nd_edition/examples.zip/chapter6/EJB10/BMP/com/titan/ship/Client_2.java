package com.titan.ship;

import javax.naming.InitialContext;
import javax.naming.Context;
import javax.naming.NamingException;
import java.rmi.RemoteException;
import java.util.Properties;
import java.util.Enumeration;

public class Client_2 {
    public static void main(String [] args){
        try {
            Context ctx = getInitialContext();
            // EJB 1.1: Use PortableRemoteObject.narrow() method
            ShipHome home = (ShipHome)ctx.lookup("ShipHome");
            home.create(2,"Utopia",4500,8939);
            home.create(3,"Valhalla",3300,93939);
            ShipPK pk = new ShipPK();
            pk.id = 1;
            Ship ship = home.findByPrimaryKey(pk);
            ship.setCapacity(4500);
            int capacity = ship.getCapacity();
            
            Enumeration enum = home.findByCapacity(4500);
            while (enum.hasMoreElements()){
                // EJB 1.1: Use PortableRemoteObject.narrow() method
                Ship aShip = (Ship)enum.nextElement();
                System.out.println(aShip.getName());
            }
        } catch (Exception e){e.printStackTrace();}
    }
    public static Context getInitialContext() 
        throws javax.naming.NamingException{
        Properties p = new Properties();
        // ... Specify the JNDI properties specific to the vendor.
        return new javax.naming.InitialContext(p);
    }
}
