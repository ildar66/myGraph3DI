package com.titan.ship;

import java.io.Serializable;

public class ShipPK implements java.io.Serializable {

    public int id;

    public ShipPK(){}
    public ShipPK(int value){
        id = value;
    }
    public int hashCode(){
       return id;
    }

    public boolean equals(Object obj){
        if(obj instanceof ShipPK){
            return (id == ((ShipPK)obj).id);
        }
        return false;
    } 

    public String toString(){
       return String.valueOf(id);
    }
}
