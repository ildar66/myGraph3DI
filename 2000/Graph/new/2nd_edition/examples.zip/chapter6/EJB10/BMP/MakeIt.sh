#!/bin/sh
# make ship

javac -classpath $CLASSPATH:$J2EE_HOME/lib/j2ee.jar:$J2EE_HOME/lib/ejb10Deployment.jar:. com/titan/ship/Ship*.java
javac -classpath $CLASSPATH:$J2EE_HOME/lib/j2ee.jar:$J2EE_HOME/lib/ejb10Deployment.jar:. com/titan/ship/MakeDD.java

java -classpath $CLASSPATH:$J2EE_HOME/lib/j2ee.jar:$J2EE_HOME/lib/ejb10Deployment.jar:. com.titan.ship.MakeDD com/titan/ship

jar cvf ship.jar com/titan/ship/*.class com/titan/ship/*.ser


