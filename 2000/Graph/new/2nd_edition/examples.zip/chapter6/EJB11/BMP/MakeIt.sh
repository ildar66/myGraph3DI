#!/bin/sh
# make ship

javac -classpath $CLASSPATH:$J2EE_HOME/lib/j2ee.jar:. com/titan/ship/Ship*.java

cp com/titan/ship/ejb-jar.xml META-INF/ejb-jar.xml
jar cvf ship.jar com/titan/ship/*.class META-INF/ejb-jar.xml
rm META-INF/ejb-jar.xml


