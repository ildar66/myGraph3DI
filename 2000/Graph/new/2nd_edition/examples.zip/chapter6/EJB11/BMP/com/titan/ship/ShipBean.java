package com.titan.ship;

import javax.ejb.EntityContext;
import javax.ejb.ObjectNotFoundException;
import javax.naming.Context;
import javax.naming.InitialContext;
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.DriverManager;
import java.sql.ResultSet;
import javax.sql.DataSource;
import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.ejb.EJBException;
import javax.naming.NamingException;
import java.util.Enumeration;
import java.util.Vector;

public class ShipBean implements javax.ejb.EntityBean {
    public int id;
    public String name;
    public int capacity;
    public double tonnage;

    public EntityContext context;
       
    public ShipPK ejbCreate(int id, String name,
        int capacity, double tonnage) throws CreateException{
        if((id < 1) || (name == null))
           throw new CreateException("Invalid Parameters");
        this.id = id;
        this.name = name;
        this.capacity = capacity;
        this.tonnage = tonnage;
        
        Connection con = null;
        PreparedStatement ps = null;
        try {
          con = this.getConnection();
          ps = con.prepareStatement(
           "insert into Ship (id, name, capacity, tonnage) " +
           "values (?,?,?,?)");
          ps.setInt(1, id);
          ps.setString(2, name);
          ps.setInt(3, capacity);
          ps.setDouble(4, tonnage);
          if (ps.executeUpdate() != 1) {
            throw new CreateException ("Failed to add Ship to database");
          }
          ShipPK primaryKey = new ShipPK();
          primaryKey.id = id;
          return primaryKey;
        }
        catch (SQLException se) {
          throw new EJBException(se);
        }
        finally {
          try {         
            if (ps != null) ps.close(); 
            if (con!= null) con.close(); 
          } catch(SQLException se){
            se.printStackTrace();
          }
        }
    }
    public void ejbPostCreate(int id, String name,
        int capacity, double tonnage){
        // Do something useful with the primary key.
    }
    public ShipPK ejbCreate(int id, String name )
        throws CreateException{
        return ejbCreate(id,name,0,0);
    }
    public void ejbPostCreate(int id, String name ){
        // Do something useful with the EJBObject reference.
    }
    public ShipPK ejbFindByPrimaryKey(ShipPK primaryKey) 
    throws FinderException {
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet result = null;
        try {
          con = this.getConnection();
          ps = con.prepareStatement(
              "select id from Ship where id = ?");
          ps.setInt(1, primaryKey.id);
          result = ps.executeQuery();
          // does ship id exist in database?
          if(!result.next()){
            throw new ObjectNotFoundException(
                "Cannot find Ship with id = "+id);
          }
        }catch (SQLException se) {
          throw new EJBException(se);
        }
        finally {
          try {
            if (result != null) result.close();
            if (ps != null) ps.close(); 
            if (con!= null) con.close(); 
          } catch(SQLException se){
            se.printStackTrace();
          }
        }
        return primaryKey;
    }
    public Enumeration ejbFindByCapacity(int capacity) 
    throws FinderException {
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet result = null;        
        try {
          con = this.getConnection();
          ps = con.prepareStatement(
              "select id from Ship where capacity = ?");
          ps.setInt(1,capacity);
          result = ps.executeQuery();
          Vector keys = new Vector();
          while(result.next()){
            ShipPK shipPk = new ShipPK();
            shipPk.id = result.getInt("id");
            keys.addElement(shipPk);
          }
          return keys.elements();
          
        }
        catch (SQLException se) {
          throw new EJBException(se);
        }
        finally {
          try {
            if (result != null) result.close();
            if (ps != null) ps.close(); 
            if (con!= null) con.close(); 
          } catch(SQLException se){
            se.printStackTrace();
          }
        }      
    }
    public void setEntityContext(EntityContext ctx){
        context = ctx;
    }
    public void unsetEntityContext(){
        context = null;
    }
    public void ejbActivate(){ }
    public void ejbPassivate(){ }
    public void ejbLoad() {
         ShipPK pk = (ShipPK) context.getPrimaryKey();
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet result = null;
        try {
          con = this.getConnection();
          ps = con.prepareStatement(
              "select name, capacity, tonnage from Ship where id = ?");
          ps.setInt(1,pk.id);
          result = ps.executeQuery();
          if(result.next()){
            id = id;
            name = result.getString("name");
            capacity = result.getInt("capacity");
            tonnage = result.getDouble("tonnage");
          } else{
            throw new EJBException(new ObjectNotFoundException(
                "Cannot find Ship with id = "+id));
          }
        }catch (SQLException se) {
          throw new EJBException(se);
        }
        finally {
          try {
            if (result != null) result.close();
            if (ps != null) ps.close(); 
            if (con!= null) con.close(); 
          } catch(SQLException se){
            se.printStackTrace();
          }
        }      
    }
    public void ejbStore() { 
        Connection con = null;
        PreparedStatement ps = null;
        try {
          con = this.getConnection();
          ps = con.prepareStatement(
              "update Ship set name = ?, capacity = ?, " +
              "tonnage = ? where id = ?");
          ps.setString(1,name);
          ps.setInt(2,capacity);
          ps.setDouble(3,tonnage);
          ps.setInt(4,id);
          if (ps.executeUpdate() != 1) {
            throw new EJBException("ejbStore failed");
          }
        }
        catch (SQLException se) {
          throw new EJBException(se);
        }
        finally {
          try {
            if (ps != null) ps.close(); 
            if (con!= null) con.close(); 
          } catch(SQLException se){
            se.printStackTrace();
          }
        }
    }
    public void ejbRemove() {
        Connection con = null;
        PreparedStatement ps = null;
        try {
          con = this.getConnection();
          ps = con.prepareStatement("delete from Ship where id = ?");
          ps.setInt(1, id);
          if (ps.executeUpdate() != 1) {
            throw new EJBException("remove failed");
          }
        }
        catch (SQLException se) {
          throw new EJBException(se);
        }
        finally {
          try {
            if (ps != null) ps.close(); 
            if (con!= null) con.close(); 
          } catch(SQLException se){
            se.printStackTrace();
          }
        }
    }
    public String getName(){
        return name;
    }
    public void setName(String n){
        name = n;
    }
    public void setCapacity(int cap){
        capacity = cap;
    }
    public int getCapacity(){
        return capacity;
    }
    public double getTonnage(){
        return tonnage;
    }
    public void setTonnage(double tons){
        tonnage = tons;
    }
    private Connection getConnection() throws SQLException {
      try {
        Context jndiCntx = new InitialContext();
        DataSource ds = 
            (DataSource)jndiCntx.lookup("java:comp/env/jdbc/titanDB");
        return ds.getConnection();
      }
      catch (NamingException ne) {
        throw new EJBException(ne);
      }
    }
}
