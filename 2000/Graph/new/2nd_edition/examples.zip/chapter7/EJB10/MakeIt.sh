#!/bin/sh
# make cabin

javac -classpath $CLASSPATH:$J2EE_HOME/lib/j2ee.jar:$J2EE_HOME/lib/ejb10Deployment.jar:. com/titan/cabin/Cabin*.java

java -classpath $CLASSPATH:$J2EE_HOME/lib/j2ee.jar:$J2EE_HOME/lib/ejb10Deployment.jar:. com.titan.cabin.MakeDD com/titan/cabin

jar cvmf com/titan/cabin/manifest cabin.jar com/titan/cabin/*.class com/titan/cabin/*.ser


# make cruise

javac -classpath $CLASSPATH:$J2EE_HOME/lib/j2ee.jar:$J2EE_HOME/lib/ejb10Deployment.jar:. com/titan/cruise/*.java

java -classpath $CLASSPATH:$J2EE_HOME/lib/j2ee.jar:$J2EE_HOME/lib/ejb10Deployment.jar:. com.titan.cruise.MakeDD com/titan/cruise

jar cvmf com/titan/cruise/manifest cruise.jar com/titan/cruise/*.class com/titan/cruise/*.ser


# make customer

javac -classpath $CLASSPATH:$J2EE_HOME/lib/j2ee.jar:$J2EE_HOME/lib/ejb10Deployment.jar:. com/titan/customer/*.java

java -classpath $CLASSPATH:$J2EE_HOME/lib/j2ee.jar:$J2EE_HOME/lib/ejb10Deployment.jar:. com.titan.customer.MakeDD com/titan/customer

jar cvmf com/titan/customer/manifest customer.jar com/titan/customer/*.class com/titan/customer/*.ser


# make processpayment

javac -classpath $CLASSPATH:$J2EE_HOME/lib/j2ee.jar:$J2EE_HOME/lib/ejb10Deployment.jar:. com/titan/processpayment/*.java

java -classpath $CLASSPATH:$J2EE_HOME/lib/j2ee.jar:$J2EE_HOME/lib/ejb10Deployment.jar:. com.titan.processpayment.MakeDD com/titan/processpayment

jar cvmf com/titan/processpayment/manifest processpayment.jar com/titan/processpayment/*.class com/titan/processpayment/*.ser


# make reservation

javac -classpath $CLASSPATH:$J2EE_HOME/lib/j2ee.jar:$J2EE_HOME/lib/ejb10Deployment.jar:. com/titan/reservation/*.java

java -classpath $CLASSPATH:$J2EE_HOME/lib/j2ee.jar:$J2EE_HOME/lib/ejb10Deployment.jar:. com.titan.reservation.MakeDD com/titan/reservation

jar cvmf com/titan/reservation/manifest reservation.jar com/titan/reservation/*.class com/titan/reservation/*.ser


# make travelagent

javac -classpath $CLASSPATH:$J2EE_HOME/lib/j2ee.jar:$J2EE_HOME/lib/ejb10Deployment.jar:. com/titan/travelagent/*.java

java -classpath $CLASSPATH:$J2EE_HOME/lib/j2ee.jar:$J2EE_HOME/lib/ejb10Deployment.jar:. com.titan.travelagent.MakeDD com/titan/travelagent


jar cvmf com/titan/travelagent/manifest travelagent.jar com/titan/travelagent/*.class com/titan/travelagent/*.ser

