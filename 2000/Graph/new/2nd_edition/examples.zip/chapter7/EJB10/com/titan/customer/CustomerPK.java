package com.titan.customer;

public class CustomerPK implements java.io.Serializable {
    public int id;
    public CustomerPK(){}
    public CustomerPK(int i){
        id = i;
    }
    public int hashCode( ){
        return id;
    }
    public boolean equals(Object obj){
        if(obj instanceof CustomerPK){
            return (id == ((CustomerPK)obj).id);
        }
        return false;
    } 
    public String toString(){
       return String.valueOf(id);
    }
    
    
}