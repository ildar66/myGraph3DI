package com.titan.customer;

import javax.ejb.deployment.EntityDescriptor;
import javax.ejb.deployment.ControlDescriptor;
import javax.naming.CompoundName;
import com.titan.cabin.CabinBean;
import java.util.Properties;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.lang.reflect.Field;

public class MakeDD {

    public static void main(String args [] ){
        try{

        if(args.length <1){
            System.out.println("must specifiy target directory");
            return;
        }
        EntityDescriptor customerDD = new EntityDescriptor();

        customerDD.setEnterpriseBeanClassName("com.titan.customer.CustomerBean");

        customerDD.setHomeInterfaceClassName("com.titan.customer.CustomerHome");

        customerDD.setRemoteInterfaceClassName("com.titan.customer.Customer");

        customerDD.setPrimaryKeyClassName("com.titan.customer.CustomerPK");


        Class beanClass = CustomerBean.class;
        Field [] persistentFields = new Field[4];
        persistentFields[0] = beanClass.getDeclaredField("id");
        persistentFields[1] = beanClass.getDeclaredField("lastName");
        persistentFields[2] = beanClass.getDeclaredField("firstName");
        persistentFields[3] = beanClass.getDeclaredField("middleName");
        customerDD.setContainerManagedFields(persistentFields);

        customerDD.setReentrant(false);

        Properties jndiProps = new Properties();
        CompoundName jndiName = null;
        jndiName = new CompoundName("CustomerHome",jndiProps);
        customerDD.setBeanHomeName(jndiName);


        ControlDescriptor cd = new ControlDescriptor();
        cd.setIsolationLevel(ControlDescriptor.TRANSACTION_READ_COMMITTED);
        cd.setMethod(null);
        cd.setRunAsMode(ControlDescriptor.CLIENT_IDENTITY);
        cd.setTransactionAttribute(ControlDescriptor.TX_REQUIRED);
        ControlDescriptor [] cdArray = {cd};
        customerDD.setControlDescriptors(cdArray);

        // Set the name to associate with the enterprise Bean in the JNDI name space.

        String fileSeparator = System.getProperties().getProperty("file.separator");

        if(! args[0].endsWith(fileSeparator))
            args[0] += fileSeparator;


        FileOutputStream fis = new FileOutputStream(args[0]+"CustomerDD.ser");
        ObjectOutputStream oos = new ObjectOutputStream(fis);
        oos.writeObject(customerDD);
        oos.flush();
        oos.close();
        fis.close();


        }catch(Throwable t){
            t.printStackTrace();
        }

    }
}

