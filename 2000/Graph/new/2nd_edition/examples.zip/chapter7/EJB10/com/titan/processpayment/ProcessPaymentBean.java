package com.titan.processpayment;

import com.titan.customer.*;

import java.sql.*;
import java.rmi.RemoteException;
import javax.ejb.SessionContext;

public class ProcessPaymentBean implements javax.ejb.SessionBean{

    final public static String CASH = "CASH";
    final public static String CREDIT = "CREDIT";
    final public static String CHECK = "CHECK";
        
    public SessionContext context;

    public void ejbCreate(){
    }
    
    public boolean byCash(Customer customer, double amount)
    throws PaymentException, RemoteException {
        return process(getCustomerID(customer),amount,
                       CASH,null,-1,-1,null);
    }
    
    public boolean byCheck(Customer customer,Check check,double amount)
    throws  PaymentException, RemoteException {
        int minCheckNumber = getMinCheckNumber();
        if (check.checkNumber > minCheckNumber){
            return process(getCustomerID(customer), amount, CHECK, 
                           check.checkBarCode,check.checkNumber,-1,null);
        }
        else {
           throw new PaymentException(
              "Check number is too low. Must be at least "+minCheckNumber);
        }
    }
    public boolean byCredit(Customer customer,CreditCard card, double amount)
    throws PaymentException, RemoteException {
        if (card.expiration.before(new java.util.Date())){
             throw new PaymentException("Expiration date has passed");
        }
        else {
            return process(getCustomerID(customer), amount, CREDIT, null,
                           -1, card.number,
                           new java.sql.Date(card.expiration.getTime()));
        }
    }
    private boolean process(long customerID, double amount, String type,
                            String checkBarCode, int checkNumber,
                            long creditNumber, java.sql.Date creditExpDate)
    throws PaymentException, RemoteException {

        Connection con = null;
        
        PreparedStatement ps = null;
        ResultSet rslt = null;
        try {
            con = getConnection();
            ps = con.prepareStatement
                ("INSERT INTO payment (customer_id, amount, type,"+ 
                  "check_bar_code,check_number,credit_number,"+
                  "credit_exp_date) VALUES (?,?,?,?,?,?,?)");
            ps.setLong(1,customerID);
            ps.setDouble(2,amount);
            ps.setString(3,type);
            ps.setString(4,checkBarCode);
            ps.setInt(5,checkNumber);
            ps.setLong(6,creditNumber);
            ps.setDate(7,creditExpDate);
            int retVal = ps.executeUpdate();
            if (retVal!=1){
                throw new RemoteException("Payment insert failed");
            }
            
            return true;
        } catch(SQLException sql){
             throw new RemoteException("",sql);
        } finally {
             try {
                 if (rslt != null) rslt.close();
                 if (ps != null) ps.close();
                 if (con!= null) con.close();
             } catch(SQLException se){se.printStackTrace();}
        }
    }
    public void ejbActivate(){}
    public void ejbPassivate(){}
    public void ejbRemove(){}
    public void setSessionContext(SessionContext ctx){
        context = ctx;
    }
    private int getCustomerID(Customer customer) throws RemoteException {
        return ((CustomerPK)customer.getPrimaryKey()).id;
    }

    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection(
        context.getEnvironment().getProperty("jdbcURL"));
    }
    private int getMinCheckNumber(){
        String min_check_string = context.getEnvironment().getProperty("minCheckNumber");
        return Integer.parseInt(min_check_string);
    }
}
