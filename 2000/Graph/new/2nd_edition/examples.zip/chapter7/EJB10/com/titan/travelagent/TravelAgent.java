package com.titan.travelagent;

import java.rmi.RemoteException;
import javax.ejb.FinderException;
import com.titan.cruise.Cruise;
import com.titan.customer.Customer;
import com.titan.processpayment.CreditCard;

public interface TravelAgent extends javax.ejb.EJBObject {

    public void setCruiseID(int cruise) 
        throws RemoteException, FinderException;
    public int getCruiseID() throws RemoteException,
                                    IncompleteConversationalState;

    public void setCabinID(int cabin) 
        throws RemoteException, FinderException;
    public int getCabinID() throws RemoteException,
                                   IncompleteConversationalState;
    public int getCustomerID( ) throws RemoteException,
                                       IncompleteConversationalState;
    
    public Ticket bookPassage(CreditCard card, double price)
        throws RemoteException,IncompleteConversationalState;   
               
    public String [] listAvailableCabins(int bedCount)
        throws RemoteException, IncompleteConversationalState;

}
