package com.titan.travelagent;

import java.rmi.RemoteException;
import javax.ejb.CreateException;
import com.titan.customer.Customer;

public interface TravelAgentHome extends javax.ejb.EJBHome {

    public TravelAgent create(Customer cust)
        throws RemoteException, CreateException;
}
