package com.titan.reservation;

import com.titan.cabin.Cabin;
import com.titan.cruise.Cruise;
import com.titan.customer.Customer;
import java.rmi.RemoteException;

public interface Reservation extends javax.ejb.EJBObject {
    public int getCabinID( ) throws RemoteException;
    public int getCruiseID( ) throws RemoteException;
    public int getCustomerID( ) throws RemoteException;
    public double getPrice( ) throws RemoteException;
}