package com.titan.processpayment;

import java.rmi.RemoteException;
import javax.ejb.CreateException;

public interface ProcessPaymentHome extends javax.ejb.EJBHome {
   public ProcessPayment create()
       throws RemoteException, CreateException;
}
