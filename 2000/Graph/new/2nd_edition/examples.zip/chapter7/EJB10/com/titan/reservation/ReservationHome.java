package com.titan.reservation;

import java.util.Enumeration;
import java.rmi.RemoteException;
import javax.ejb.CreateException;
import javax.ejb.FinderException;
import com.titan.cruise.Cruise;
import com.titan.customer.Customer;
import com.titan.cabin.Cabin;

public interface ReservationHome extends javax.ejb.EJBHome {

    public Reservation create(Customer customer, Cruise cruise,Cabin cabin, double price)
    throws RemoteException, CreateException;

    public Reservation findByPrimaryKey(ReservationPK pk)
    throws RemoteException, FinderException;

}