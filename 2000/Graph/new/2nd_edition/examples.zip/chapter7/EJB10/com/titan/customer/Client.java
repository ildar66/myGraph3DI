package com.titan.customer;


import javax.naming.InitialContext;
import javax.naming.Context;
import javax.naming.NamingException;
import javax.ejb.CreateException;
import java.rmi.RemoteException;
import java.util.Properties;

public class Client {

    public static void main(String args[]){

        try{
            Context jndiContext = getInitialContext();
            CustomerHome home = (CustomerHome)jndiContext.lookup("CustomerHome");
            Customer c = home.create(1, "Monson-Haefel","Richard","Wayne");
            System.out.println(c.getLastName());
            System.out.println(c.getFirstName());



        }catch(java.rmi.RemoteException re){re.printStackTrace();}
         catch(javax.naming.NamingException ne){ne.printStackTrace();}

         catch(javax.ejb.CreateException ce){ce.printStackTrace();}

    }

    static public javax.naming.Context getInitialContext()
    throws javax.naming.NamingException{
        Properties p = new Properties();
        // ... specify the JNDI properties specific to the vendor
        return new javax.naming.InitialContext(p);
    }
}