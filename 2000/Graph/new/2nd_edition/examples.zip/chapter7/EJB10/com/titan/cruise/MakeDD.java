package com.titan.cruise;

import javax.ejb.deployment.EntityDescriptor;
import javax.ejb.deployment.ControlDescriptor;
import javax.naming.CompoundName;
import com.titan.cabin.CabinBean;
import java.util.Properties;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.lang.reflect.Field;

public class MakeDD {

    public static void main(String args [] ){
        try{

        if(args.length <1){
            System.out.println("must specifiy target directory");
            return;
        }
        EntityDescriptor cruiseDD = new EntityDescriptor();

        cruiseDD.setEnterpriseBeanClassName("com.titan.cruise.CruiseBean");

        cruiseDD.setHomeInterfaceClassName("com.titan.cruise.CruiseHome");

        cruiseDD.setRemoteInterfaceClassName("com.titan.cruise.Cruise");

        cruiseDD.setPrimaryKeyClassName("com.titan.cruise.CruisePK");


        Class beanClass = CruiseBean.class;
        Field [] persistentFields = new Field[3];
        persistentFields[0] = beanClass.getDeclaredField("id");
        persistentFields[1] = beanClass.getDeclaredField("name");
        persistentFields[2] = beanClass.getDeclaredField("shipID");
        cruiseDD.setContainerManagedFields(persistentFields);

        cruiseDD.setReentrant(false);

        Properties jndiProps = new Properties();
        CompoundName jndiName = null;
        jndiName = new CompoundName("CruiseHome",jndiProps);
        cruiseDD.setBeanHomeName(jndiName);


        ControlDescriptor cd = new ControlDescriptor();
        cd.setIsolationLevel(ControlDescriptor.TRANSACTION_READ_COMMITTED);
        cd.setMethod(null);
        cd.setRunAsMode(ControlDescriptor.CLIENT_IDENTITY);
        cd.setTransactionAttribute(ControlDescriptor.TX_REQUIRED);
        ControlDescriptor [] cdArray = {cd};
        cruiseDD.setControlDescriptors(cdArray);

        // Set the name to associate with the enterprise Bean in the JNDI name space.

        String fileSeparator = System.getProperties().getProperty("file.separator");

        if(! args[0].endsWith(fileSeparator))
            args[0] += fileSeparator;


        FileOutputStream fis = new FileOutputStream(args[0]+"CruiseDD.ser");
        ObjectOutputStream oos = new ObjectOutputStream(fis);
        oos.writeObject(cruiseDD);
        oos.flush();
        oos.close();
        fis.close();


        }catch(Throwable t){
            t.printStackTrace();
        }

    }
}

