package com.titan.processpayment;

import javax.ejb.deployment.*;
import javax.naming.CompoundName;
import java.util.*;
import java.io.*;

public class MakeDD {

    public static void main(String args [] ){
        try {
        if(args.length <1){
            System.out.println("must specify target directory");
            return;
        }

        SessionDescriptor paymentDD = new SessionDescriptor();
        paymentDD.setRemoteInterfaceClassName(
          "com.titan.processpayment.ProcessPayment");
        paymentDD.setHomeInterfaceClassName(
          "com.titan.processpayment.ProcessPaymentHome");
        paymentDD.setEnterpriseBeanClassName(
          "com.titan.processpayment.ProcessPaymentBean");
        paymentDD.setSessionTimeout(60);
        paymentDD.setStateManagementType(
            SessionDescriptor.STATELESS_SESSION);

        Properties props = new Properties();
        props.put("jdbcURL","jdbc:<subprotocol>:<subname>"); 

        props.put("minCheckNumber","1000");
        paymentDD.setEnvironmentProperties(props);

        ControlDescriptor cd = new ControlDescriptor();
        cd.setIsolationLevel(ControlDescriptor.TRANSACTION_READ_COMMITTED);
        cd.setMethod(null);
        cd.setRunAsMode(ControlDescriptor.CLIENT_IDENTITY);
        cd.setTransactionAttribute(ControlDescriptor.TX_REQUIRED);
        ControlDescriptor [] cdArray = {cd};
        paymentDD.setControlDescriptors(cdArray);

        CompoundName jndiName = 
            new CompoundName("ProcessPaymentHome", new Properties());
        paymentDD.setBeanHomeName(jndiName);

        String fileSeparator = 
            System.getProperties().getProperty("file.separator");
        if (! args[0].endsWith(fileSeparator))
            args[0] += fileSeparator;

        FileOutputStream fis = 
            new FileOutputStream(args[0]+"ProcessPaymentDD.ser");
        ObjectOutputStream oos = new ObjectOutputStream(fis);
        oos.writeObject(paymentDD);
        oos.flush();
        oos.close();
        fis.close();
        } catch(Throwable t){t.printStackTrace();}
    }
}
