package com.titan.reservation;

import javax.naming.*;
import java.rmi.*;
import com.titan.reservation.*;
import java.util.*;
import com.titan.cruise.*;
import com.titan.customer.*;
import com.titan.cabin.*;

public class Client {

    public static void main(String args[]){
        try{


        Context jndiContext = getInitialContext();
        CustomerHome custHome =  (CustomerHome)jndiContext.lookup("CustomerHome");
        Customer customer = custHome.findByPrimaryKey(new CustomerPK(1));
        CruiseHome cruiseHome =  (CruiseHome)jndiContext.lookup("CruiseHome");
        Cruise cruise = cruiseHome.findByPrimaryKey(new CruisePK(1));
        CabinHome cabinHome =  (CabinHome)jndiContext.lookup("CabinHome");
        CabinPK pk = new CabinPK();
        pk.id = 22;
        Cabin cabin = cabinHome.findByPrimaryKey(pk);

        ReservationHome home = (ReservationHome)jndiContext.lookup("ReservationHome");
        Reservation res = home.create(customer,cruise,cabin,1300);

        System.out.println(res.getCustomerID());
        System.out.println(res.getCruiseID());
        System.out.println(res.getCabinID());

        }catch(java.rmi.RemoteException re)
           {
             System.out.println("RemoteException thrown");
             re.printStackTrace();
           }
        catch(Throwable t)
           {
            t.printStackTrace();
           }
  }
  static public Context getInitialContext() throws Exception {
    Properties p = new Properties();
    // ... specify the JNDI properties specific to the vendor
    return new InitialContext(p);
  }

}
