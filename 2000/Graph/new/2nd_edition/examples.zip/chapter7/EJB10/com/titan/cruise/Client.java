package com.titan.cruise;

import com.titan.cabin.CabinHome;
import com.titan.cabin.Cabin;
import com.titan.cabin.CabinPK;

import javax.naming.InitialContext;
import javax.naming.Context;
import javax.naming.NamingException;
import javax.ejb.CreateException;
import java.rmi.RemoteException;
import java.util.Properties;

public class Client {

    public static void main(String args[]){

        try{
            Context jndiContext = getInitialContext();
            CruiseHome home = (CruiseHome)jndiContext.lookup("CruiseHome");
            Cruise c = home.create(1,"Eastern Journey",1);
            System.out.println(c.getName());
            System.out.println(c.getShipID());



        }catch(java.rmi.RemoteException re){re.printStackTrace();}
         catch(javax.naming.NamingException ne){ne.printStackTrace();}

         catch(javax.ejb.CreateException ce){ce.printStackTrace();}

    }

    static public javax.naming.Context getInitialContext()
    throws javax.naming.NamingException{
        Properties p = new Properties();
        // ... specify the JNDI properties specific to the vendor
        return new javax.naming.InitialContext(p);
    }
}
