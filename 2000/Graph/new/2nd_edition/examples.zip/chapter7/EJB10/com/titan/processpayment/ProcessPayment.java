package com.titan.processpayment;

import java.rmi.RemoteException;
import java.util.Date;
import com.titan.customer.Customer;


public interface ProcessPayment extends javax.ejb.EJBObject {

    public boolean byCheck(Customer customer, Check check, double amount)
      throws RemoteException,PaymentException;

    public boolean byCash(Customer customer, double amount)
      throws RemoteException,PaymentException;

    public boolean byCredit(Customer customer, CreditCard card, double amount)
      throws RemoteException,PaymentException;
}
