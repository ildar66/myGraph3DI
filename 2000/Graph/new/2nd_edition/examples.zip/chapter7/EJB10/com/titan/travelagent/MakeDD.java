package com.titan.travelagent;

import javax.ejb.deployment.*;
import javax.naming.CompoundName;
import java.util.*;
import java.io.*;

public class MakeDD {

    public static void main(String args [] ){
        try {
            if (args.length <1){
                System.out.println("must specify target directory");
                return;
            }

        SessionDescriptor sd = new SessionDescriptor();

        sd.setEnterpriseBeanClassName(
            "com.titan.travelagent.TravelAgentBean");
        sd.setHomeInterfaceClassName(
            "com.titan.travelagent.TravelAgentHome");
        sd.setRemoteInterfaceClassName(
            "com.titan.travelagent.TravelAgent");

        sd.setSessionTimeout(60);
        sd.setStateManagementType(SessionDescriptor.STATEFUL_SESSION);

        ControlDescriptor cd = new ControlDescriptor();
        cd.setIsolationLevel(ControlDescriptor.TRANSACTION_READ_COMMITTED);
        cd.setMethod(null);
        cd.setRunAsMode(ControlDescriptor.CLIENT_IDENTITY);
        cd.setTransactionAttribute(ControlDescriptor.TX_REQUIRED);
        ControlDescriptor [] cdArray = {cd};
        sd.setControlDescriptors(cdArray);
         
        // Set enterprise Bean39s environment properties.
        Properties ep = new Properties();
        ep.put("CruiseHome","CruiseHome");
        ep.put("CabinHome","CabinHome");
        ep.put("ReservationHome","ReservationHome");
        ep.put("ProcessPaymentHome","ProcessPaymentHome");
        ep.put("ShipHome","ShipHome");
        ep.put("jdbcURL","jdbc:<subprotocol>:<subname>");
        sd.setEnvironmentProperties(ep);

        Properties jndiProps = new Properties();
        CompoundName jndiName = 
            new CompoundName("TravelAgentHome",jndiProps);
        sd.setBeanHomeName(jndiName);

        String fileSeparator = 
            System.getProperties().getProperty("file.separator");
        if(! args[0].endsWith(fileSeparator))
            args[0] += fileSeparator;

        FileOutputStream fis = 
            new FileOutputStream(args[0]+"TravelAgentDD.ser");
        ObjectOutputStream oos = new ObjectOutputStream(fis);
        oos.writeObject(sd);
        oos.flush();
        oos.close();
        fis.close();
        } catch(Throwable t){t.printStackTrace();}
    }
}
