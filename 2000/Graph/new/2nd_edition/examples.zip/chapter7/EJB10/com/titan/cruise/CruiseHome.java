package com.titan.cruise;
import java.rmi.RemoteException;

import java.util.Enumeration;

public interface CruiseHome extends javax.ejb.EJBHome {

    public Cruise create(int id, String name,int shipID)
    throws RemoteException, javax.ejb.CreateException;

    public Cruise findByPrimaryKey(CruisePK pk)
    throws RemoteException, javax.ejb.FinderException;
}
