package com.titan.reservation;

import javax.ejb.deployment.EntityDescriptor;
import javax.ejb.deployment.ControlDescriptor;
import javax.naming.CompoundName;
import com.titan.reservation.ReservationBean;
import java.util.Properties;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.lang.reflect.Field;

public class MakeDD {

    public static void main(String args [] ){
        try{

        if(args.length <1){
            System.out.println("must specifiy target directory");
            return;
        }
        EntityDescriptor reservationDD = new EntityDescriptor();

        reservationDD.setEnterpriseBeanClassName("com.titan.reservation.ReservationBean");

        reservationDD.setHomeInterfaceClassName("com.titan.reservation.ReservationHome");

        reservationDD.setRemoteInterfaceClassName("com.titan.reservation.Reservation");

        reservationDD.setPrimaryKeyClassName("com.titan.reservation.ReservationPK");

        
        Class beanClass = ReservationBean.class;
        Field [] persistentFields = new Field[4];
        persistentFields[0] = beanClass.getDeclaredField("customerID");
        persistentFields[1] = beanClass.getDeclaredField("cruiseID");
        persistentFields[2] = beanClass.getDeclaredField("cabinID");
        persistentFields[3] = beanClass.getDeclaredField("price");
        reservationDD.setContainerManagedFields(persistentFields);

        reservationDD.setReentrant(false);

        CompoundName jndiName = new CompoundName("ReservationHome",new Properties());
        reservationDD.setBeanHomeName(jndiName);


        ControlDescriptor cd = new ControlDescriptor();
        cd.setIsolationLevel(ControlDescriptor.TRANSACTION_READ_COMMITTED);
        cd.setMethod(null);
        cd.setRunAsMode(ControlDescriptor.CLIENT_IDENTITY);
        cd.setTransactionAttribute(ControlDescriptor.TX_REQUIRED);
        ControlDescriptor [] cdArray = {cd};
        reservationDD.setControlDescriptors(cdArray);

        // Set the name to associate with the enterprise Bean in the JNDI name space.

        String fileSeparator = System.getProperties().getProperty("file.separator");

        if(! args[0].endsWith(fileSeparator))
            args[0] += fileSeparator;


        FileOutputStream fos = new FileOutputStream(args[0]+"ReservationDD.ser");
        ObjectOutputStream oos = new ObjectOutputStream(fos);
        oos.writeObject(reservationDD);
        oos.flush();
        oos.close();
        fos.close();


        }catch(Throwable t){
            t.printStackTrace();
        }

    }
}

