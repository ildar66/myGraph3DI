package com.titan.processpayment;

public class Check implements java.io.Serializable {
    String checkBarCode;
    int checkNumber;
    public Check(String barCode, int number){
        checkBarCode = barCode;
        checkNumber = number;
    }
}
