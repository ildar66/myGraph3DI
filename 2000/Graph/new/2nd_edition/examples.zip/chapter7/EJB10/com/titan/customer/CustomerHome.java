package com.titan.customer;
import java.rmi.RemoteException;

public interface CustomerHome extends javax.ejb.EJBHome {

    public Customer create(int id, String lastName, String firstName, String middleName)
    throws RemoteException, javax.ejb.CreateException;

    public Customer findByPrimaryKey(CustomerPK pk)
    throws RemoteException, javax.ejb.FinderException;

}