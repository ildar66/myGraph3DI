package com.titan.customer;

import javax.ejb.EntityContext;

public class CustomerBean implements javax.ejb.EntityBean {

    public int id;
    public String lastName;
    public String firstName;
    public String middleName;

    public void ejbCreate(int id, String lastName, String firstName, String middleName){
        this.id = id;
        this.lastName = lastName;
        this.firstName = firstName;
        this.middleName = middleName;
    }
    public void ejbPostCreate(int id, String lastName, String firstName, String middleName){
        // do nothing. Required
    }
    public String getLastName(){
        return lastName;
    }
    public void setLastName(String name){
        lastName = name;
    }
    public String getFirstName(){
        return firstName;
    }
    public void setFirstName(String name){
        firstName = name;
    }
    public String getMiddleName(){
        return middleName;
    }
    public void setMiddleName(String name){
        middleName = name;
    }
	public void setEntityContext(EntityContext ctx){
	     //context = ctx;
    }
    public void unsetEntityContext(){
         //context = null;
    }
    public void ejbActivate(){
        // not implmented
    }
    public void ejbPassivate(){
        // not implmented
    }
    public void ejbLoad(){
        // not implmented
    }
    public void ejbStore(){
        // not implmented
    }
    public void ejbRemove(){
        // not implmented
    }
}