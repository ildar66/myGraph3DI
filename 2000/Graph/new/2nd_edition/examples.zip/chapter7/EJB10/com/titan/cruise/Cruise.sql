CREATE TABLE CRUISE 
(
   ID         INT PRIMARY KEY, 
   NAME       CHAR(30), 
   SHIP_ID    INT
)
