package com.titan.travelagent;

import com.titan.cruise.Cruise;
import com.titan.cabin.Cabin;
import com.titan.customer.Customer;
import java.rmi.RemoteException;

public class Ticket implements java.io.Serializable{
    public int cruiseID;
    public int cabinID;
    public double price;
    public String description;
    
    public Ticket(Customer customer, Cruise cruise, Cabin cabin, 
        double price) throws javax.ejb.FinderException, RemoteException,  
        javax.naming.NamingException{
        
       description = customer.getFirstName()+" "+customer.getMiddleName()+ 
           " " + customer.getLastName() + 
           " has been booked for the " + cruise.getName().trim() + 
           " cruise on ship " + cruise.getShipID() + ".\n" +  
           " Your accommodations include " + cabin.getName().trim() + 
           " a " + cabin.getBedCount() + 
           " bed cabin on deck level " + cabin.getDeckLevel() + 
           ".\n Total charge = " + price;
    }
        
    public String toString(){
        return description;
    }
}
