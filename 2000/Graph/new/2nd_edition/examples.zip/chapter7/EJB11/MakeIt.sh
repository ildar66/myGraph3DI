#!/bin/sh
# make cabin

javac -classpath $CLASSPATH:$J2EE_HOME/lib/j2ee.jar:. com/titan/cabin/Cabin*.java

cp com/titan/cabin/ejb-jar.xml META-INF/ejb-jar.xml
jar cvf cabin.jar com/titan/cabin/*.class META-INF/ejb-jar.xml


# make cruise

javac -classpath $CLASSPATH:$J2EE_HOME/lib/j2ee.jar:. com/titan/cruise/Cruise*.java

cp com/titan/cruise/ejb-jar.xml META-INF/ejb-jar.xml
jar cvf cruise.jar com/titan/cruise/*.class META-INF/ejb-jar.xml


# make customer

javac -classpath $CLASSPATH:$J2EE_HOME/lib/j2ee.jar:. com/titan/customer/Customer*.java

cp com/titan/customer/ejb-jar.xml META-INF/ejb-jar.xml
jar cvf customer.jar com/titan/customer/*.class META-INF/ejb-jar.xml


# make processpayment

javac -classpath $CLASSPATH:$J2EE_HOME/lib/j2ee.jar:. com/titan/processpayment/*.java

cp com/titan/processpayment/ejb-jar.xml META-INF/ejb-jar.xml
jar cvf processpayment.jar com/titan/processpayment/*.class META-INF/ejb-jar.xml


# make reservation

javac -classpath $CLASSPATH:$J2EE_HOME/lib/j2ee.jar:. com/titan/reservation/Reservation*.java

cp com/titan/reservation/ejb-jar.xml META-INF/ejb-jar.xml
jar cvf reservation.jar com/titan/reservation/*.class META-INF/ejb-jar.xml


# make travelagent

javac -classpath $CLASSPATH:$J2EE_HOME/lib/j2ee.jar:. com/titan/travelagent/*.java

cp com/titan/travelagent/ejb-jar.xml META-INF/ejb-jar.xml
jar cvf travelagent.jar com/titan/travelagent/*.class META-INF/ejb-jar.xml

rm META-INF/ejb-jar.xml
