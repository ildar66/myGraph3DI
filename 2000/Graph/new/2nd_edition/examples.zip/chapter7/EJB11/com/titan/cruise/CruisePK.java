package com.titan.cruise;

public class CruisePK implements java.io.Serializable {
    public int id;
    public CruisePK(){}
    public CruisePK(int i){
        id = i;
    }
    public int hashCode( ){
        return id;
    }
    public boolean equals(Object obj){
        if(obj instanceof CruisePK){
            return (id == ((CruisePK)obj).id);
        }
        return false;
    } 
    public String toString(){
       return String.valueOf(id);
    }
    
}
