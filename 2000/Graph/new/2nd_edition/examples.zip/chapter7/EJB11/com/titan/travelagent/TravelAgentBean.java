package com.titan.travelagent;

import com.titan.cabin.*;
import com.titan.cruise.*;
import com.titan.customer.*;
import com.titan.processpayment.*;
import com.titan.reservation.*;

import java.sql.*;
import javax.sql.DataSource;
import java.util.Vector;
import java.rmi.RemoteException;
import javax.naming.NamingException;
import javax.ejb.EJBException;


public class TravelAgentBean implements javax.ejb.SessionBean {

    public Customer customer;
    public Cruise cruise;
    public Cabin cabin;

    public javax.ejb.SessionContext ejbContext;
    public javax.naming.Context jndiContext;

    public void ejbCreate(Customer cust){
        customer = cust;
    }
    public int getCustomerID( )
    throws IncompleteConversationalState{
        try{
            if(customer == null)
                throw new IncompleteConversationalState();
            return ((CustomerPK)customer.getPrimaryKey()).id;
        }catch(RemoteException re){
            throw new EJBException(re);
        }
    }
    public int getCruiseID( )
    throws IncompleteConversationalState{
        try{
            if(cruise == null)
                throw new IncompleteConversationalState();
            return ((CruisePK)cruise.getPrimaryKey()).id;
        }catch(RemoteException re){
            throw new EJBException(re);
        }
        
    }
        
    public int getCabinID( )
    throws IncompleteConversationalState{
        try{
            if(cabin==null)
                throw new IncompleteConversationalState();
            return ((CabinPK)cabin.getPrimaryKey()).id;
        }catch(RemoteException re){
            throw new EJBException(re);
        }
    }
    public void setCabinID(int cabinID)
    throws javax.ejb.FinderException{
        try{
            CabinHome home = (CabinHome)getHome("CabinHome",CabinHome.class);
            CabinPK pk = new CabinPK();
            pk.id=cabinID;
            cabin = home.findByPrimaryKey(pk);
        }catch(RemoteException re){
            throw new EJBException(re);
        }
    }
    public void setCruiseID(int cruiseID)
    throws javax.ejb.FinderException{
        try{
            CruiseHome home = (CruiseHome)getHome("CruiseHome", CruiseHome.class);
            cruise = home.findByPrimaryKey(new CruisePK(cruiseID));
        }catch(RemoteException re){
            throw new EJBException(re);
        }
        
    }
    public Ticket bookPassage(CreditCard card, double price)
    throws IncompleteConversationalState{
                    

        if(customer == null || cruise == null || cabin == null){
            throw new IncompleteConversationalState();
        }
        try{
            ReservationHome resHome =
                (ReservationHome) getHome("ReservationHome",ReservationHome.class);
            Reservation reservation =
            resHome.create(customer, cruise, cabin,price);
            ProcessPaymentHome ppHome =
                (ProcessPaymentHome) getHome("ProcessPaymentHome",ProcessPaymentHome.class);
            ProcessPayment process = ppHome.create();
            process.byCredit(customer, card, price);

            Ticket ticket = new Ticket(customer,cruise,cabin,price);
            return ticket;
        }catch(Exception e){
            throw new EJBException(e);
        }
    }
    public void ejbRemove(){}
    public void ejbActivate(){}
    public void ejbPassivate(){}

    public void setSessionContext(javax.ejb.SessionContext cntx){
        ejbContext = cntx;
        try{
          jndiContext = new javax.naming.InitialContext();
        }catch(NamingException ne){
            throw new EJBException(ne);
        }
    }
    protected Object getHome(String name,Class type){
        try{
            Object ref = jndiContext.lookup("java:comp/env/ejb/"+name);
            return javax.rmi.PortableRemoteObject.narrow(ref, type);
        }catch(NamingException ne){
            throw new EJBException(ne);
        }
    }
    private Connection getConnection() throws SQLException{
        try{
           DataSource ds = (DataSource)jndiContext.lookup("java:comp/env/jdbc/titanDB");
           return ds.getConnection( );
        }catch(NamingException ne){throw new EJBException(ne);}
    }
    public String [] listAvailableCabins(int bedCount)
    throws IncompleteConversationalState{

        if(cruise == null) throw new IncompleteConversationalState();


        Connection con = null;
        PreparedStatement ps = null;;
        ResultSet result = null;
        try {
            int cruiseID = ((CruisePK)cruise.getPrimaryKey()).id;
            int shipID = cruise.getShipID();
            con = getConnection();
            ps = con.prepareStatement(
                "select ID, NAME, DECK_LEVEL  from CABIN "+
                "where SHIP_ID = ? and ID NOT IN "+
                "(SELECT CABIN_ID FROM RESERVATION WHERE CRUISE_ID = ?)");

            ps.setInt(1,shipID);
            ps.setInt(2,cruiseID);
            result = ps.executeQuery();
            Vector vect = new Vector();
            while(result.next()){
                StringBuffer buf = new StringBuffer();
                buf.append(result.getString(1));
                buf.append(',');
                buf.append(result.getString(2));
                buf.append(',');
                buf.append(result.getString(3));
                vect.addElement(buf.toString());
            }
            String [] returnArray = new String[vect.size()];
            vect.copyInto(returnArray);
            return returnArray;
        }
        catch (Exception e) {
            throw new EJBException(e);
        }
        finally {
            try {
                if (result != null) result.close();
                if (ps != null) ps.close();
                if (con!= null) con.close();
            }catch(SQLException se){se.printStackTrace();}
        }
    }
}
