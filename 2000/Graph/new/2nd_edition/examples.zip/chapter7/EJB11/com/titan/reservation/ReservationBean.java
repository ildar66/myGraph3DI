package com.titan.reservation;

import com.titan.cabin.*;
import com.titan.cruise.*;
import com.titan.customer.*;

import javax.ejb.*;
import java.rmi.RemoteException;


public class ReservationBean implements javax.ejb.EntityBean {
    
    public int customerID;
    public int cruiseID;
    public int cabinID;
    public double price;
    
   
    public javax.ejb.EntityContext ejbContext;

    public ReservationPK ejbCreate(Customer customer, Cruise cruise, Cabin cabin, double price) {
        try {
            this.customerID = ((CustomerPK)customer.getPrimaryKey()).id;
            this.cruiseID = ((CruisePK)cruise.getPrimaryKey()).id;
            this.cabinID = ((CabinPK)cabin.getPrimaryKey()).id;
            this.price = price;
        }
        catch (RemoteException re) {
            throw new EJBException(re);
        }
        return null;
    }

    public void ejbPostCreate(Customer customer, Cruise cruise, Cabin cabin, double price){
        // do nothing;
    }
    public double getPrice( ){
        return price;
    }
    public int getCabinID( ){
        return cabinID;
    }
    public int getCustomerID( ){
        return customerID;
    }
    public int getCruiseID( ){
        return cruiseID;
    }
	public void setEntityContext(javax.ejb.EntityContext ctx){
	     //not implemented
    }
    public void unsetEntityContext(){
	     //not implemented
    }
    public void ejbActivate(){
        // not implmented
    }
    public void ejbPassivate(){
        // not implmented
    }
    public void ejbLoad(){
        // not implmented
    }
    public void ejbStore(){
        // not implmented
    }
    public void ejbRemove(){
        // not implmented
    }
}
