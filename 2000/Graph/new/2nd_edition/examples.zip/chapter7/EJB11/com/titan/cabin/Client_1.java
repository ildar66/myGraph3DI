package com.titan.cabin;

import com.titan.cabin.CabinHome;
import com.titan.cabin.Cabin;
import com.titan.cabin.CabinPK;

import javax.naming.InitialContext;
import javax.naming.Context;
import javax.naming.NamingException;
import java.rmi.RemoteException;
import java.util.Properties;

public class Client_1 {
    public static void main(String [] args){
        try {
            Context jndiContext = getInitialContext();
            Object obj = jndiContext.lookup("ejb/CabinHome");
            System.out.println("found it! ="+ obj);
            CabinHome home = (CabinHome) javax.rmi.PortableRemoteObject.narrow(obj, CabinHome.class);

            System.out.println("narrowed it! ="+ home);

            Cabin cabin_1 = home.create(1);
            System.out.println("created it! ="+ cabin_1);
            cabin_1.setName("Master Suite");
            cabin_1.setDeckLevel(1);
            cabin_1.setShip(1);
            cabin_1.setBedCount(3);
                   
            CabinPK pk = new CabinPK();
            pk.id = 1;
            System.out.println("keyed it! ="+ pk);
            
            Cabin cabin_2 = home.findByPrimaryKey(pk);
            System.out.println("found by key! ="+ cabin_2);
            System.out.println(cabin_2.getName());
            System.out.println(cabin_2.getDeckLevel());
            System.out.println(cabin_2.getShip());
            System.out.println(cabin_2.getBedCount());

        } catch (java.rmi.RemoteException re){re.printStackTrace();}
          catch (javax.naming.NamingException ne){ne.printStackTrace();}
          catch (javax.ejb.CreateException ce){ce.printStackTrace();}
          catch (javax.ejb.FinderException fe){fe.printStackTrace();}
    }

    public static Context getInitialContext() 
                          throws javax.naming.NamingException {

        Properties p = new Properties();
        // ... Specify the JNDI properties specific to the vendor.
        //return new javax.naming.InitialContext(p);
        return getJ2EERIInitialContext();
    }

    public static Context getJ2EERIInitialContext() 
                          throws javax.naming.NamingException {

        return new javax.naming.InitialContext();
    }

    public static Context getGemstoneInitialContext()
                          throws javax.naming.NamingException {
       Properties p = new Properties();
       // Uncomment if you have the com.gemstone.* classes available
       //p.put(com.gemstone.naming.Defaults.NAME_SERVICE_HOST,"localhost");
       String port = System.getProperty("com.gemstone.naming.NameServicePort",
                                        "10200");
       // Uncomment if you have the com.gemstone.* classes available
       //p.put(com.gemstone.naming.Defaults.NAME_SERVICE_PORT, port);
       p.put(Context.INITIAL_CONTEXT_FACTORY,"com.gemstone.naming.GsCtxFactory");
       return new InitialContext(p);
    }

    public static Context getWeblogicInitialContext() 
                          throws javax.naming.NamingException {
       Properties p = new Properties();
       p.put(Context.INITIAL_CONTEXT_FACTORY,
             "weblogic.jndi.TengahInitialContextFactory");
       p.put(Context.PROVIDER_URL, "t3://localhost:7001");
       return new javax.naming.InitialContext(p);
    }
}
