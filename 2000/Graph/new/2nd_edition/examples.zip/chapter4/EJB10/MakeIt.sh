#!/bin/sh
# make cabin

javac -classpath $CLASSPATH:$J2EE_HOME/lib/j2ee.jar:$J2EE_HOME/lib/ejb10Deployment.jar:. com/titan/cabin/*.java

java -classpath $CLASSPATH:$J2EE_HOME/lib/j2ee.jar:$J2EE_HOME/lib/ejb10Deployment.jar:. com.titan.cabin.MakeDD com/titan/cabin

jar cvmf com/titan/cabin/manifest cabin.jar com/titan/cabin/*.class com/titan/cabin/*.ser


# make travelagent

javac -classpath $CLASSPATH:$J2EE_HOME/lib/j2ee.jar:$J2EE_HOME/lib/ejb10Deployment.jar:. com/titan/travelagent/*.java

java -classpath $CLASSPATH:$J2EE_HOME/lib/j2ee.jar:$J2EE_HOME/lib/ejb10Deployment.jar:. com.titan.travelagent.MakeDD com/titan/travelagent


jar cvmf com/titan/travelagent/manifest travelagent.jar com/titan/travelagent/*.class com/titan/travelagent/*.ser

