package com.titan.cabin;

import javax.ejb.EntityContext;

public class CabinBean implements javax.ejb.EntityBean {

    public int id;
    public String name;
    public int deckLevel;
    public int ship;
    public int bedCount;
    
    public void ejbCreate(int id){
        this.id = id;
    }
    public void ejbPostCreate(int id){
        // Do nothing. Required.
    }
    public String getName(){
        return name;
    }
    public void setName(String str){
        name = str;
    }
    public int getShip(){
        return ship;
    }
    public void setShip(int sp) {
        ship = sp;
    }
    public int getBedCount(){
        return bedCount;
    }
    public void setBedCount(int bc){
        bedCount = bc;
    }  
    public int getDeckLevel(){
        return deckLevel;
    }
    public void setDeckLevel(int level ){
        deckLevel = level;
    }

    public void setEntityContext(EntityContext ctx){
         // Not implemented.
    }
    public void unsetEntityContext(){
         // Not implemented.
    }
    public void ejbActivate(){
        // Not implemented.
    }
    public void ejbPassivate(){
        // Not implemented.
    }
    public void ejbLoad(){
        // Not implemented.
    }
    public void ejbStore(){
        // Not implemented.
    }
    public void ejbRemove(){
        // Not implemented.
    }
}
