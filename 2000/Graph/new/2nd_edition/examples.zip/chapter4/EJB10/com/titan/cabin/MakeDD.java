package com.titan.cabin;

import javax.ejb.deployment.EntityDescriptor;
import javax.ejb.deployment.ControlDescriptor;
import javax.naming.CompoundName;
import com.titan.cabin.CabinBean;
import java.util.Properties;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.lang.reflect.Field;

public class MakeDD {

    public static void main(String [] args){
        try {
          if (args.length <1){
            System.out.println("must specify target directory");
            return;
          }
        
        EntityDescriptor cabinDD = new EntityDescriptor();
        
        cabinDD.setEnterpriseBeanClassName("com.titan.cabin.CabinBean");
        cabinDD.setHomeInterfaceClassName("com.titan.cabin.CabinHome");
        cabinDD.setRemoteInterfaceClassName("com.titan.cabin.Cabin");
        cabinDD.setPrimaryKeyClassName("com.titan.cabin.CabinPK");

        Class beanClass = CabinBean.class;
        Field [] persistentFields = new Field[5];
        persistentFields[0] = beanClass.getDeclaredField("id");
        persistentFields[1] = beanClass.getDeclaredField("name");
        persistentFields[2] = beanClass.getDeclaredField("deckLevel");
        persistentFields[3] = beanClass.getDeclaredField("ship");
        persistentFields[4] = beanClass.getDeclaredField("bedCount");

        cabinDD.setContainerManagedFields(persistentFields);
        
        cabinDD.setReentrant(false);   
        
        CompoundName jndiName = new CompoundName("CabinHome", 
                                                 new Properties());
        cabinDD.setBeanHomeName(jndiName);
        
        ControlDescriptor cd = new ControlDescriptor();
        
        cd.setIsolationLevel(ControlDescriptor.TRANSACTION_READ_COMMITTED);
        cd.setTransactionAttribute(ControlDescriptor.TX_REQUIRED);
        
        cd.setRunAsMode(ControlDescriptor.CLIENT_IDENTITY);
        
        cd.setMethod(null);
        ControlDescriptor [] cdArray = {cd};
        cabinDD.setControlDescriptors(cdArray);
 
        String fileSeparator = 
            System.getProperties().getProperty("file.separator");
        if (! args[0].endsWith(fileSeparator))
            args[0] += fileSeparator;

        FileOutputStream fos = new FileOutputStream(args[0]+"CabinDD.ser");
        ObjectOutputStream oos = new ObjectOutputStream(fos);
        oos.writeObject(cabinDD);
        oos.flush();
        oos.close();
        fos.close();

        } catch (Throwable t){ t.printStackTrace();}
    }
}
