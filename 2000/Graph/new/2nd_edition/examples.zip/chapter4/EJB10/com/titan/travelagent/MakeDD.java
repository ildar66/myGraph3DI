package com.titan.travelagent;

import javax.ejb.deployment.*;
import javax.naming.CompoundName;
import java.util.*;
import java.io.*;

public class MakeDD {

    public static void main(String [] args){
        try {

        if(args.length <1){
            System.out.println("must specify target directory");
            return;
        }

        SessionDescriptor sd = new SessionDescriptor();

        sd.setEnterpriseBeanClassName(
            "com.titan.travelagent.TravelAgentBean");
        sd.setHomeInterfaceClassName(
            "com.titan.travelagent.TravelAgentHome");
        sd.setRemoteInterfaceClassName(
            "com.titan.travelagent.TravelAgent");

        sd.setSessionTimeout(300);
        sd.setStateManagementType(SessionDescriptor.STATELESS_SESSION);

        ControlDescriptor cd = new ControlDescriptor();
        cd.setIsolationLevel(ControlDescriptor.TRANSACTION_READ_COMMITTED);
        cd.setMethod(null);
        cd.setRunAsMode(ControlDescriptor.CLIENT_IDENTITY);
        cd.setTransactionAttribute(ControlDescriptor.TX_REQUIRED);
        ControlDescriptor [] cdArray = {cd};
        sd.setControlDescriptors(cdArray);

        CompoundName jndiName = 
            new CompoundName("TravelAgentHome", new Properties());
        sd.setBeanHomeName(jndiName);

        String fileSeparator = 
            System.getProperties().getProperty("file.separator");
        if(! args[0].endsWith(fileSeparator))
            args[0] += fileSeparator;

        FileOutputStream fis = 
            new FileOutputStream(args[0]+"TravelAgentDD.ser");
        ObjectOutputStream oos = new ObjectOutputStream(fis);
        oos.writeObject(sd);
        oos.flush();
        oos.close();
        fis.close();
        } catch(Throwable t) { t.printStackTrace(); }
    }
}
