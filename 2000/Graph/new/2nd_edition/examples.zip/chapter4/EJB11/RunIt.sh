#!/bin/sh
# run cabin Client_1

runclient -client chapter4beans.ear -name CabinClient_1


