#!/bin/sh
# make cabin clients

javac -classpath $CLASSPATH:$J2EE_HOME/lib/j2ee.jar:. com/titan/cabin/Client*.java


# make travelagent clients

javac -classpath $CLASSPATH:$J2EE_HOME/lib/j2ee.jar:. com/titan/travelagent/Client*.java

