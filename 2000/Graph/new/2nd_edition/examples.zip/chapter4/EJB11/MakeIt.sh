#!/bin/sh
# make cabin

javac -classpath $CLASSPATH:$J2EE_HOME/lib/j2ee.jar:. com/titan/cabin/Cabin*.java

cp com/titan/cabin/ejb-jar.xml META-INF/ejb-jar.xml
jar cvf cabin.jar com/titan/cabin/Cabin*.class META-INF/ejb-jar.xml


# make travelagent

javac -classpath $CLASSPATH:$J2EE_HOME/lib/j2ee.jar:. com/titan/travelagent/TravelAgent*.java

copy com/titan/travelagent/ejb-jar.xml META-INF/ejb-jar.xml
jar cvf travelagent.jar com/titan/travelagent/TravelAgent*.class META-INF/ejb-jar.xml

rm META-INF/ejb-jar.xml

