package com.titan.travelagent;

import com.titan.cabin.CabinHome;
import com.titan.cabin.Cabin;
import com.titan.cabin.CabinPK;

import javax.naming.InitialContext;
import javax.naming.Context;
import javax.naming.NamingException;
import javax.ejb.CreateException;
import java.rmi.RemoteException;
import java.util.Properties;

public class Client_1 {
    public static int SHIP_ID = 1;
    public static int BED_COUNT = 3;

    public static void main(String [] args){
        try {
           Context jndiContext = getInitialContext();
           Object obj = jndiContext.lookup("ejb/TravelAgentHome");
           TravelAgentHome home = (TravelAgentHome) javax.rmi.PortableRemoteObject.narrow(obj, TravelAgentHome.class);

           TravelAgent reserve = home.create();
        
           // Get a list of all cabins on ship 1 with a bed count of 3.
           String list [] = reserve.listCabins(SHIP_ID,BED_COUNT);
        
           for(int i = 0; i < list.length; i++){
              System.out.println(list[i]);
           }
        
        } catch(java.rmi.RemoteException re){re.printStackTrace();}
          catch(Throwable t){t.printStackTrace();}
  }
  static public Context getInitialContext() throws Exception {
    Properties p = new Properties();
    // ... Specify the JNDI properties specific to the vendor.
    return new InitialContext();
  }
}
