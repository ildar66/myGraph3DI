package com.titan.travelagent;

import com.titan.cabin.Cabin;
import com.titan.cabin.CabinHome;
import com.titan.cabin.CabinPK;
import java.rmi.RemoteException;
import javax.naming.InitialContext;
import javax.naming.Context;
import java.util.Properties;
import java.util.Vector;
import javax.ejb.EJBException;

public class TravelAgentBean implements javax.ejb.SessionBean {

   public void ejbCreate() {
   // Do nothing.
   }
   public String [] listCabins(int shipID, int bedCount)
      throws EJBException{
        try {
            javax.naming.Context jndiContext = new InitialContext();
            Object obj = jndiContext.lookup("ejb/CabinHome");

            CabinHome home = (CabinHome)
                javax.rmi.PortableRemoteObject.narrow(obj, CabinHome.class);
    
            Vector vect = new Vector();
            CabinPK pk = new CabinPK();
            Cabin cabin;
            for(int i = 1; ; i++){
               pk.id = i;
               try {
                  cabin = home.findByPrimaryKey(pk);
                } catch(javax.ejb.FinderException fe){
                    break;
                }
                // Check to see if the bed count and ship ID match.
                if (cabin.getShip() == shipID && 
                    cabin.getBedCount() == bedCount){
                  String details = 
                    i+","+cabin.getName()+","+cabin.getDeckLevel();
                  vect.addElement(details);
                }
            }
        
            String [] list = new String[vect.size()];
            vect.copyInto(list);
            return list;
       
       } catch(javax.naming.NamingException ne){
            throw new EJBException(ne);
       } catch(java.rmi.RemoteException re){
            throw new EJBException(re);
       }    
   }

   private javax.naming.Context getInitialContext() 
   throws javax.naming.NamingException{
      Properties p = new Properties();
      // ... Specify the JNDI properties specific to the vendor.
      return new javax.naming.InitialContext(p);
   }

   public void ejbRemove(){}
   public void ejbActivate(){}
   public void ejbPassivate(){}
   public void setSessionContext(javax.ejb.SessionContext cntx){}
}
