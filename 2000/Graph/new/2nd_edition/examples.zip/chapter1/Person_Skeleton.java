import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.net.Socket;
import java.net.ServerSocket;

public class Person_Skeleton extends Thread {
    PersonServer myServer;

    public Person_Skeleton(PersonServer server){
        // Get a reference to the object server that this skeleton wraps.
        this.myServer = server;
    }
    public void run(){
      try {
        // Create a server socket on port 9000.
        ServerSocket serverSocket = new ServerSocket(9000);
        // Wait for and obtain a socket connection from stub.
        Socket socket = serverSocket.accept();
        while (socket != null){      
            // Create an input stream to receive requests from stub.
            ObjectInputStream inStream = 
                new ObjectInputStream(socket.getInputStream());
            // Read next method request from stub. Block until request is
            // sent.
            String method = (String)inStream.readObject();
            // Evaluate the type of method requested.
            if (method.equals("age")){
                // Invoke business method on server object.
                int age = myServer.getAge();
                // Create an output stream to send return values back to
                // stub.
                ObjectOutputStream outStream = 
                    new ObjectOutputStream(socket.getOutputStream());
                // Send results back to stub.
                outStream.writeInt(age);
                outStream.flush();
            } else if(method.equals("name")){
                // Invoke business method on server object.
                String name = myServer.getName();
                // Create an output stream to send return values back to
                // the stub.
                ObjectOutputStream outStream = 
                    new ObjectOutputStream(socket.getOutputStream());
                // Send results back to stub.
                outStream.writeObject(name);
                outStream.flush();
            }
        }
      } catch(Throwable t) {t.printStackTrace();System.exit(0); }
    }
    public static void main(String args [] ){
         // Obtain a unique instance Person.
        PersonServer person = new PersonServer("Richard", 34);
        Person_Skeleton skel = new Person_Skeleton(person);
        skel.start();
    }
}
