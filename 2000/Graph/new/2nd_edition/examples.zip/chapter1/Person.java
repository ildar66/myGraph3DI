public interface Person {
    public int getAge() throws Throwable;
    public String getName() throws Throwable;
}
