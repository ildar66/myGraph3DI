import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.net.Socket;

public class Person_Stub implements Person {
    Socket socket;
    
    public Person_Stub() throws Throwable {
       // Create a network connection to the skeleton. 
       // Replace "myhost" with your own IP Address of your computer.
       socket = new Socket("myhost",9000);
    }
    public int getAge() throws Throwable{
       // When this method is invoked, stream the method name to the
       // skeleton.
       ObjectOutputStream outStream = 
           new ObjectOutputStream(socket.getOutputStream());
       outStream.writeObject("age");
       outStream.flush();
       ObjectInputStream inStream = 
           new ObjectInputStream(socket.getInputStream());
       return inStream.readInt();
    }
    public String getName() throws Throwable {
        // When this method is invoked, stream the method name to the
        // skeleton.
        ObjectOutputStream outStream = 
            new ObjectOutputStream(socket.getOutputStream());
        outStream.writeObject("name");
        outStream.flush();
        ObjectInputStream inStream = 
            new ObjectInputStream(socket.getInputStream());
        return (String)inStream.readObject();
    }
}
