#!/bin/sh
# make person

javac -classpath $CLASSPATH:$J2EE_HOME/lib/j2ee.jar:. *.java

