package com.titan.cabin;

public class CabinPK implements java.io.Serializable {
    public int id;

    public int hashCode( ){
        return id;
    }
    public boolean equals(Object obj){
        if(obj instanceof CabinPK){
            return (id == ((CabinPK)obj).id);
        }
        return false;
    } 
    public String toString(){
       return String.valueOf(id);
    }
    
}
