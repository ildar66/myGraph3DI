package com.titan.cabin;

import javax.naming.InitialContext;
import javax.naming.Context;
import javax.naming.NamingException;
import javax.ejb.EJBObject;
import javax.ejb.Handle;
import java.rmi.RemoteException;
import java.util.Properties;

public class VendorX_CabinHandle
    implements javax.ejb.Handle, java.io.Serializable{

    private CabinPK primary_key;
    private String home_name;
    private Properties jndi_properties;

    public VendorX_CabinHandle(CabinPK pk, String hn, Properties p){
        primary_key = pk;
        home_name = hn;
        jndi_properties = p;
    }

    public EJBObject getEJBObject() throws RemoteException {
      try {
        Context ctx = new InitialContext(jndi_properties);

        CabinHome home =
            (CabinHome) ctx.lookup(home_name);
        return home.findByPrimaryKey(primary_key);
      } catch(javax.ejb.FinderException fe){
            throw new RemoteException("Cannot locate EJB object",fe);
      } catch(javax.naming.NamingException ne){
            throw new RemoteException("Cannot locate EJB object",ne);
      }
    }
}
