#!/bin/sh
# make example handle class

javac -classpath $CLASSPATH:$J2EE_HOME/lib/j2ee.jar:. com/titan/cabin/*.java

